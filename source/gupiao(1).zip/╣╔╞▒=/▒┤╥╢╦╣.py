#!/usr/bin/env python
# coding: utf-8

# In[7]:


import pandas as pd
import numpy as np
import talib


# In[12]:


def jisuan(DF_SHURU):
    DATA_DATAFAIME = pd.DataFrame()
    DATA_DATAFAIME['a2'] = talib.RSI(np.array(DF_SHURU.close), 7) #%rsi指标
    DATA_DATAFAIME['a4'] = talib.CCI(np.array(DF_SHURU.high),np.array(DF_SHURU.low),np.array(DF_SHURU.close),14)  #;%cci指标
    a1 = [0]
    for i in range(1,len(DF_SHURU.close)):
        a1.append(DF_SHURU.close[i]-DF_SHURU.close[i-1])
    DATA_DATAFAIME['a1']=a1 

    y = []
    for i in range(0,len(DF_SHURU.close)-1):
        y.append(DF_SHURU.close[i+1]-DF_SHURU.close[i])
    y.append(0)
    DATA_DATAFAIME['y']=y
    DATA_DATAFAIME['y'][DATA_DATAFAIME['y']>0]=1
    DATA_DATAFAIME['y'][DATA_DATAFAIME['y']==0]=0
    DATA_DATAFAIME['y'][DATA_DATAFAIME['y']<0]=-1

    DATA_DATAFAIME['a1'][DATA_DATAFAIME['a1']>0]=1
    DATA_DATAFAIME['a1'][DATA_DATAFAIME['a1']==0]=0
    DATA_DATAFAIME['a1'][DATA_DATAFAIME['a1']<0]=-1

    #a2<20,20≤a2≤80，a2>80
    DATA_DATAFAIME['a2'][DATA_DATAFAIME['a2']<30]=1
    DATA_DATAFAIME['a2'][DATA_DATAFAIME['a2']>60]=3

    for i in range(len(DATA_DATAFAIME['a2'])):
        if 30<=DATA_DATAFAIME.a2[i]<=60:
            DATA_DATAFAIME.loc[i,'a2']=2

    for i in range(len(DATA_DATAFAIME['a4'])):
        if -50<=DATA_DATAFAIME.a4[i]<=50:
            DATA_DATAFAIME.loc[i,'a4']=2
        elif DATA_DATAFAIME.a4[i]<-50: 
            DATA_DATAFAIME.loc[i,'a4']=1
        else:
            DATA_DATAFAIME.loc[i,'a4']=3
    return DATA_DATAFAIME


# In[17]:


def beiyesi(data):
    y_ = [-1,0,1]
    a1_ = [-1,0,1]
    dic = {}

    for i in y_:
        for j in a1_:
            dic['y'+str(i)+'_a1'+str(j)] = sum(
                    data['a1'][data['y']==i]==j)/sum(
                            data['y']==i)

    a2_ = [1,2,3]
    a4_ = [1,2,3]
    for i in y_:
        for j in a2_:
            dic['y'+str(i)+'_a2'+str(j)] = sum(
                    data['a2'][data['y']==i]==j)/sum(
                            data['y']==i)
    for i in y_:
        for j in a4_:
            dic['y'+str(i)+'_a4'+str(j)] = sum(
                    data['a4'][data['y']==i]==j)/sum(
                            data['y']==i)
    data.iloc[19,:]

    y_ = sum(data['y']==-1)/len(data['y'])
    y0 = sum(data['y']==0)/len(data['y'])
    y1 = sum(data['y']==1)/len(data['y'])

    py_ = y_*dic['y-1_a22']*dic['y-1_a41']*dic['y-1_a1-1']
    py0 = y0*dic['y0_a22']*dic['y0_a41']*dic['y0_a1-1']
    py1 = y1*dic['y1_a22']*dic['y1_a41']*dic['y1_a1-1']
    return y_,y0,y1


# In[27]:


df=pd.read_excel('股票价量数据.xlsx', sheet_name=None)
lis=[]
for i in list(df):
    df1=pd.read_excel('股票价量数据.xlsx',header=3,sheet_name=i)
    df1=df1.dropna()
    df1=jisuan(df1)
    lis.append(list(beiyesi(df1)))         
dff=pd.DataFrame([],columns=['股票名称','上升概率'])
for i in range(len(lis)):
    dff=dff.append(pd.DataFrame([[list(df)[i],lis[i][2]+lis[i][1]]],columns=['股票名称','上升概率']))
print('推荐股票')
print(dff.sort_values('上升概率',ascending=False).iloc[:1])


# In[ ]:




